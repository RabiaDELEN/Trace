  import 'package:flutter/material.dart';

 Widget bottomNavigationBar () {
   return Align(
     alignment: Alignment.bottomCenter,
     child: Container(
       decoration: BoxDecoration(
         boxShadow: [
           BoxShadow(
             offset: Offset(0, -3),
             color: Colors.black.withOpacity(0.25),
             blurRadius: 10)
         ],
         color: Color(0xFFEFF5FB),
       ),
       width: double.infinity,
       padding: EdgeInsets.symmetric(vertical: 13),
       child: Row(
         mainAxisAlignment: MainAxisAlignment.spaceAround,
         children: [
           buildNavIcon(iconData: Icons.house_outlined, active: true),
           buildNavIcon(iconData: Icons.account_balance_wallet_outlined, active: false),
           buildNavIcon(iconData: Icons.people , active: false),
         ],
       )
     ),
   );
 }

 Widget buildNavIcon({required IconData iconData, required bool active}) {
   return Icon(iconData,
   size:40,
   color: Color(
   active ? 0xFF0001FC : 0XFF0A1034,
   ));
 }
