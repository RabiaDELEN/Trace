import 'package:flutter/material.dart';
import 'package:untitled/bottomNavigationBar.dart';

class CategoriesPage extends StatelessWidget {
CategoriesPage({Key? key}) : super(key: key);
 final List<String> categories = [
    "ALBİNZM",
    "MOR ÇATI",
    "KİMSEV",
    "TEV",
    "LÖSEV",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Padding(
               padding: const EdgeInsets.symmetric(horizontal: 16.0),
               child: Column(
                 crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     SizedBox(height: 9),

                     Icon(Icons.category_outlined, color: Color(0xFF131212), size:35),

                     //CATEGORİES

                     Column(
                       children: categories
                           .map((String title) => buildCategory(title))
                           .toList()),

                    ],
                )
          ),
          bottomNavigationBar(),
        ]
      )));
  }
}

 Widget buildCategory(String title) {
  return Container(
    padding: EdgeInsets.all(38),
    margin: EdgeInsets.only(bottom: 16),
    width: double.infinity,
    decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 4,
              offset: Offset(0,4)),
        ]),
    child: Text(
      title,
      style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: Color(0xFF131212)),
    ),
  );

}